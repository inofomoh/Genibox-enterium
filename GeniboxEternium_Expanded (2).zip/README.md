# Genibox Eternium Expanded

An all-in-one next-gen AAA game engine with complete support for open worlds, AI, Metahumans, multiplayer, and cinematics. Built from scratch for the future of gaming.